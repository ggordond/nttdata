package com.bootcampjava.event.web;

import com.bootcampjava.event.service.IEventService;
import com.bootcampjava.event.web.model.EventModel;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * Controller for Event
 * @author
 *
 */
/** uso de Rest controller */

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/event")
@Slf4j
public class EventController {
	
	@Autowired
	private final IEventService eventService;

	/**
	 * Get list of events
	 * @return
	 * @throws Exception
	 */
	@GetMapping()	
	@Operation(summary = "Get list of events")
	public ResponseEntity<Object> getAll() throws Exception {
		List<EventModel> response =  eventService.findAll();
		log.info("getAll" + "OK");
		log.debug(response.toString());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	/**
	 * Get list of events by name and description
	 * @return
	 * @throws Exception
	 */
	@GetMapping(path = { "{name}/{description}" }, produces = { "application/json" })	
	@Operation(summary = "Get list of events by Name and Description")
	public ResponseEntity<Object> getByNameAndDescription(@PathVariable("name") String name, @PathVariable("description") String description) throws Exception {
		List<EventModel> response =  eventService.findByNameAndDescription(name, description);
		log.info("getByNameAndDescription" + "OK");
		log.debug(response.toString());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	/**
	 * Get event by id
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@GetMapping(path = { "{id}" }, produces = { "application/json" })
	@Operation(summary = "Get event by id")
	public ResponseEntity<EventModel> getById(@PathVariable("id") Long id) throws Exception{
		EventModel response = eventService.findById(id);
		log.info("getById" + "OK");
		log.debug(id.toString());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	/**
	 * Create event
	 * @param eventModel
	 * @return
	 * @throws Exception
	 */
	@PostMapping()
	@Operation(summary = "Create event")
	public ResponseEntity<Object> create(@Valid @RequestBody EventModel eventModel) throws Exception {
		EventModel response = eventService.create(eventModel);
		log.info("create" + "OK");
		log.debug(eventModel.toString());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	/**
	 * Update event by id
	 * @param id
	 * @param eventModel
	 * @throws Exception
	 */
	@PutMapping(path = { "{id}" }, produces = { "application/json" })
	@Operation(summary = "Update event by id")
	public void update(		
			@PathVariable("id") Long id,
			@Valid @RequestBody EventModel eventModel) throws Exception {		
		eventService.update(id, eventModel);
		log.info("update" + "OK");
		log.debug(id.toString()+ "/" + eventModel.toString());
	}
	
	/**
	 * Delete event by id
	 * @param id
	 * @throws Exception
	 * @author
	 */
	@DeleteMapping({ "{id}" })
	@Operation(summary = "Delete event by id")
	public void deleteById(@PathVariable("id") Long id) throws Exception {
		eventService.deleteById(id);
		log.info("deleteById" + "OK");
		log.debug(id.toString());
	}
}
