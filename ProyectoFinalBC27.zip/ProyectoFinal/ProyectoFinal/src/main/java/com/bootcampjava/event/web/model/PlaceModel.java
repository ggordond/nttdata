package com.bootcampjava.event.web.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PlaceModel {

	@JsonProperty("placeId")
 	private Long id;
	
	private String name;
	
	private String address;
	
	private String reference;
	
	private String district;
	
	private String province;
	
	private String department;

	private Long size;
}
