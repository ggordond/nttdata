package com.bootcampjava.event.bootstrap;

import com.bootcampjava.event.domain.Category;
import com.bootcampjava.event.domain.Place;
import com.bootcampjava.event.repository.CategoryRepository;
import com.bootcampjava.event.repository.EventRepository;
import com.bootcampjava.event.repository.PlaceRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootStrapData implements CommandLineRunner {

	private final CategoryRepository categoryRepository;
	private final PlaceRepository placeRepository;
	private final EventRepository eventRepository;
			
	public BootStrapData(CategoryRepository categoryRepository, PlaceRepository placeRepository, EventRepository eventRepository) {
		super();
		this.categoryRepository = categoryRepository;
		this.placeRepository = placeRepository;
		this.eventRepository = eventRepository;
	}

	@Override
	public void run(String... args) throws Exception {

		categoryRepository.save(Category.builder()
								.name("Concierto")
								.build());
		
		categoryRepository.save(Category.builder()
								.name("Cursos")
								.build());
		
		categoryRepository.save(Category.builder()
								.name("Teatro")
								.build());
		System.out.println("Categories Initialized");
		placeRepository.save(Place.builder()
							.name("Gran Teatro Del Peru")
							.address("Av. Javier Prado Oeste 5222")
							.department("Lima")
							.district("San Borja")
							.province("Lima")
							.reference("None")
							.size(Long.valueOf(1000))
							.build()
							);
		System.out.println("Place Initialized");
		
	}

}
