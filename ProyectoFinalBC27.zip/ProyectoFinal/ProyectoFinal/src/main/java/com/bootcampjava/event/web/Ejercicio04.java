package com.bootcampjava.event.web;


import java.util.function.BiFunction;

/*
 * Crear una función anónima o stream que reciba dos parámetros, un string y un numero entero.
 * La función retorna un string el cual será de repetir la cadena tantas veces el número entero
 */
public class Ejercicio04 {

    public static void main(String[] args) {

        String result = "";

        BiFunction<String,Integer,String> repeat = (word, number) -> word.repeat(number);

        result = repeat.apply("Hola",10);
        System.out.println(result);

    }

}
