package com.bootcampjava.event.service.mapper;

import com.bootcampjava.event.domain.Event;
import com.bootcampjava.event.web.model.EventModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EventMapper {

	 Event eventModelToEvent (EventModel model);
	 
	 EventModel eventToEventModel (Event event);
	 
	 List<EventModel> eventsToEventModels(List<Event> events);
	 
	 @Mapping(target = "id", ignore = true)
	 void update(@MappingTarget Event entity, EventModel updateEntity);
}
