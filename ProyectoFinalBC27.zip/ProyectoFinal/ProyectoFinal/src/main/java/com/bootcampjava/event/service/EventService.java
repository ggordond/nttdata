package com.bootcampjava.event.service;

import com.bootcampjava.event.domain.Event;
import com.bootcampjava.event.repository.EventRepository;
import com.bootcampjava.event.service.mapper.EventMapper;
import com.bootcampjava.event.web.model.EventModel;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor

public class EventService implements IEventService {
	/**  operacion para la validacion del monto solicitado de afp
	 *
	 */
	private final EventRepository eventRepository;
	private final EventMapper eventMapper;

	
	@Override
	public List<EventModel> findAll()  throws Exception {
		List<Event> events = eventRepository.findAll();
		return eventMapper.eventsToEventModels(events);
	}
	@Override
	public List<EventModel> findByNameAndDescription(String name, String description)  throws Exception {
		List<Event> events = eventRepository.findByNameIgnoreCaseAndDescriptionIgnoreCase(name, description);
		return eventMapper.eventsToEventModels(events);
	}
	
	@Override
	public EventModel findById(Long id) throws Exception {
		Optional<Event> event = eventRepository.findById(id);
		if(event.isPresent())	return eventMapper.eventToEventModel(event.get());
		else throw new Exception("No se encontraron datos");
	}

	@Override
	public EventModel create(EventModel eventModel)  throws Exception{
		Event event = eventRepository.save(eventMapper.eventModelToEvent(eventModel));

		return eventMapper.eventToEventModel(event);


	}

	@Override
	public void update(Long id, EventModel eventModel)  throws Exception {
		Optional<Event> eventOptional = eventRepository.findById(id);

		if(eventOptional.isPresent()) {
			Event eventToUpdate = eventOptional.get();
			eventMapper.update(eventToUpdate, eventModel);
			eventRepository.save(eventToUpdate);
		}
		else throw new Exception("No se encontraron datos");
	}

	@Override
	public void deleteById(Long id)  throws Exception {
		eventRepository.deleteById(id);
	}

}




