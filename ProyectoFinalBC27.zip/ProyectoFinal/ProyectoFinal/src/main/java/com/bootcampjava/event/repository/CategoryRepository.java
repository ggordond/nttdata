package com.bootcampjava.event.repository;

import com.bootcampjava.event.domain.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long>  {

}
