package com.bootcamp.serviceproducto.util;

public class Constantes {

    public static final Integer TIPO_PERSONAL = 1;
    public static final Integer TIPO_EMPRESARIAL = 2;
    public static final Integer TIPO_PRODUCTO_PASIVO = 1;
    public static final Integer TIPO_PRODUCTO_ACTIVO = 2;
    public static final Integer SUB_TIPO_CA = 2;
    public static final Integer SUB_TIPO_PF = 3;
}
