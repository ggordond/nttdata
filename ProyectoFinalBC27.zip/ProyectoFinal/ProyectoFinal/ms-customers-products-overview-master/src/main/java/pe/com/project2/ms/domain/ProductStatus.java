package pe.com.project2.ms.domain;

public enum ProductStatus {
    ACTIVE, INACTIVE, BLOCK, DELETED
}
