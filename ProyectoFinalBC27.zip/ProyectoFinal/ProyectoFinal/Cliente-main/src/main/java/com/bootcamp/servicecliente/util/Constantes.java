package com.bootcamp.servicecliente.util;

public final class Constantes {

    public static final Integer TIPO_PERSONAL = 1;
    public static final Integer TIPO_EMPRESARIAL = 2;
    public static final Integer TIPO_PRODUCTO_PASIVO = 1;
    public static final Integer TIPO_PRODUCTO_ACTIVO = 2;

}
